import TodoItem from './TodoItem';

const TodoList = ({ todos, toggleComplete, removeTodo, editTodo }) => {
    return (
        <div className="w-full max-w-lg">
            {todos.map((todo) => (
                <TodoItem
                    key={todo.id}
                    todo={todo}
                    toggleComplete={toggleComplete}
                    removeTodo={removeTodo}
                    editTodo={editTodo}
                />
            ))}
        </div>
    );
};

export default TodoList;
