import { useState, useEffect } from 'react';
import TodoList from '@/component/TodoList';
import TodoForm from '@/component/TodoForm';

const Home = () => {
    const [todos, setTodos] = useState([]);

    useEffect(() => {
        const savedTodos = JSON.parse(localStorage.getItem('todos')) || [];
        setTodos(savedTodos);
    }, []);

    useEffect(() => {
        localStorage.setItem('todos', JSON.stringify(todos));
    }, [todos]);

    const addTodo = (todo) => {
        setTodos([todo, ...todos]);
    };

    const toggleComplete = (id) => {
        setTodos(todos.map((todo) =>
            todo.id === id ? { ...todo, completed: !todo.completed } : todo
        ));
    };

    const removeTodo = (id) => {
        setTodos(todos.filter((todo) => todo.id !== id));
    };

    const editTodo = (id, newTask) => {
        setTodos(todos.map((todo) =>
            todo.id === id ? { ...todo, task: newTask } : todo
        ));
    };

    return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 py-12 px-4 sm:px-6 lg:px-8">
            <h1 className="text-3xl font-bold mb-6">Todo List</h1>
            <TodoForm addTodo={addTodo} />
            <TodoList
                todos={todos}
                toggleComplete={toggleComplete}
                removeTodo={removeTodo}
                editTodo={editTodo}
            />
        </div>
    );
};

export default Home;
