import { useState } from 'react';

const TodoItem = ({ todo, toggleComplete, removeTodo, editTodo }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [newTask, setNewTask] = useState(todo.task);

    const handleEdit = () => {
        setIsEditing(!isEditing);
        if (isEditing) {
            editTodo(todo.id, newTask);
        }
    };

    return (
        <div className="flex items-center justify-between bg-white p-4 rounded-lg shadow-md mb-2">
            <div className="flex items-center">
                <input
                    type="checkbox"
                    checked={todo.completed}
                    onChange={() => toggleComplete(todo.id)}
                    className="mr-2"
                />
                {isEditing ? (
                    <input
                        type="text"
                        value={newTask}
                        onChange={(e) => setNewTask(e.target.value)}
                        className="text-lg"
                    />
                ) : (
                    <span className={`text-lg ${todo.completed ? 'line-through text-gray-500' : ''}`}>
            {todo.task}
          </span>
                )}
            </div>
            <div>
                <button onClick={handleEdit} className="text-blue-500 hover:text-blue-700 mr-2">
                    {isEditing ? 'Save' : 'Edit'}
                </button>
                <button onClick={() => removeTodo(todo.id)} className="text-red-500 hover:text-red-700">
                    Delete
                </button>
            </div>
        </div>
    );
};

export default TodoItem;
