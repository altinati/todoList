import { useState, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';

const TodoForm = ({ addTodo }) => {
    const [task, setTask] = useState('');

    useEffect(() => {
        const savedTask = localStorage.getItem('task');
        if (savedTask) {
            setTask(savedTask);
        }
    }, []);

    useEffect(() => {
        localStorage.setItem('task', task);
    }, [task]);

    const handleSubmit = (e) => {
        e.preventDefault();
        if (task.trim()) {
            addTodo({
                id: uuidv4(),
                task,
                completed: false,
            });
            setTask('');
            localStorage.removeItem('task');
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <input
                type="text"
                value={task}
                onChange={(e) => setTask(e.target.value)}
                placeholder="Add a new task"
            />
            <button type="submit">Add</button>
        </form>
    );
};

export default TodoForm;
